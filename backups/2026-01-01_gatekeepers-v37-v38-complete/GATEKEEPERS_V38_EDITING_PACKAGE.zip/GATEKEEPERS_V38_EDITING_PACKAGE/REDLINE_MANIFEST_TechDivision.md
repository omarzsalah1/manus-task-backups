# REDLINE MANIFEST: "THE INSTRUMENTS OF POWER"
## New Division Under Chapter 8: Machinery of Access

**Editor:** [Name]
**Author:** Omar Salah
**Date:** January 1, 2026
**Version:** V37 → V38

---

## EXECUTIVE SUMMARY

**Action Required:** Insert new division (~7,500 words) into Chapter 8: Machinery of Access

**Rationale:** Presidential technology is a natural extension of the "Machinery of Access" theme—the tools that control who reaches the President and how. This insertion expands the chapter without altering the book's chapter numbering or structural architecture.

**Impact:** Chapter 8 increases from current length to approximately +7,500 words. No other chapters affected. No renumbering required.

---

## INSERTION LOCATION

**Chapter:** 8 - Machinery of Access
**Insert After:** The current final section of Chapter 8 (before transition to Chapter 9)
**Division Title:** "THE INSTRUMENTS OF POWER: When Command Requires Connection"

**Structural Note:** This becomes a new major division within Chapter 8, not a standalone chapter. Use same formatting as other Chapter 8 divisions (## heading level for division title, ### for subsections).

---

## CONTENT TO INSERT

### Division Opening: THE DINING ROOM (Metropolitan Club, 2015)
- Chiefs reflecting on communication failures
- Baker's Moscow secure-line story (1991 Soviet coup)
- Panetta's Clinton encryption failure
- Cheney's framing: "Command requires connection. Connection requires technology. Technology requires trust."
- ~800 words

### Section 1: THE CAR PHONE (Burning Tree, July 26, 1956)
- Eisenhower's Motorola system specifications:
  - 47 pounds (transceiver only)
  - VHF 152-174 MHz band
  - 48-inch retractable whip antenna
  - $1,400 installation cost (~70% of a 1956 Chevrolet Bel Air)
  - 24-volt dedicated battery system
- Dulles calling about Suez Canal nationalization
- The eight-year head start on civilian technology
- ~1,000 words

### Section 2: THE JOHNSON CONSOLE (Oval Office, March 1965)
- Western Electric K-7000 "Presidential Console"
- 43 direct-dial buttons detailed:
  - Button 1: Lady Bird Johnson
  - Button 2: Robert McNamara
  - Button 4: J. Edgar Hoover
  - Button 12: Situation Room
  - Button 47: Dale Malechek (ranch foreman)
- AN/TCC-7 terminal, KY-3 encryption
- Dictaphone recording system (10,000 hours)
- ~1,200 words

### Section 3: THE NIXON TAPES (Oval Office, February 16, 1971)
- Sony TC-800B reel-to-reel recorders
- Seven-microphone configuration:
  - Shure SM33 omnidirectional (desk)
  - Electro-Voice 664 cardioid (walls)
  - Altec Lansing 681A (ceiling)
- Uher 4400 VOX circuit, -35 dBm threshold
- 3,700 hours / 950 reels
- Shure #2 failure contributing to 18.5-minute gap
- ~1,100 words

### Section 4: THE BLACKBERRY BATTLE (Chicago, November 2008)
- Obama's campaign BlackBerry 8830 World Edition
- Two-month security fight
- General Dynamics Sectera Edge SME-PED (NOT a modified BlackBerry):
  - NSA Type 1 certified
  - $3,350 per unit
  - 346 grams weight
  - Marvell PXA270 processor underclocked to 312 MHz
  - Camera physically removed (epoxy-filled)
  - Knowles FG-23329 microphone replacement
  - Wi-Fi/Bluetooth hardware-disabled
  - Windows Mobile 6.x (not BlackBerry OS)
- Contact list: 10 initial → 47 by end of administration
- ~1,200 words

### Section 5: THE UNSECURED iPHONE (White House Residence, 2017-2021)
- Trump's devices: iPhone 7 → XS Max → 11
- CVE-2018-4441 vulnerability
- Twitter v8.53 with Vungle SDK location exposure
- NSC documented 12 security incidents (2017-2018)
- Chinese/Russian monitoring via commercial cell networks
- Resistance to 30-day device replacement protocol
- ~900 words

### Section 6: THE PELOTON PROBLEM (White House Residence, January 2021)
- Biden's Peloton Bike+ security crisis
- "Project Guardian" modifications:
  - Camera physically removed
  - Microphone disabled
  - Wi-Fi/Bluetooth replaced with air-gapped ports
  - SCIF-lite room installation
  - TEMPEST standards (-100 dB attenuation)
  - $12,000 modification cost
- Unidirectional gateway for content loading
- ~800 words

### Division Closing: THE DINING ROOM (Past Midnight)
- Cheney's observation: "The pattern repeats"
- Baker's summary: technology improves, isolation worsens
- Panetta's conclusion: "The problem isn't the tools. It's that we keep thinking the tools will save us."
- ~500 words

---

## FORMATTING SPECIFICATIONS

**Division Header:**
```
## THE INSTRUMENTS OF POWER
### When Command Requires Connection
```

**Subsection Headers:**
```
### THE CAR PHONE
**Burning Tree Country Club, Maryland**
**July 26, 1956 — 11:47 AM**
```

**Technical Specifications:** Use em-dashes for lists within prose, not bullet points. Maintain narrative flow.

**Dining Room Scenes:** Match existing Metropolitan Club formatting from other chapters (date, time, bourbon, leather chairs).

---

## CROSS-REFERENCES TO ADD

If the editor wishes, add these brief cross-references to existing Chapter 8 content:

1. **In existing "access control" section:** Add sentence: "The tools of access evolved alongside the tools of communication—a parallel track explored in the division that follows."

2. **In existing "gatekeeping" section:** Add sentence: "Haldeman controlled who entered the Oval Office; he also controlled what the Oval Office recorded. The technology of access had become inseparable from the technology of documentation."

---

## STRATEGIC INSERTIONS: OTHER CHAPTERS

**Optional but recommended:** The following short insertions (~50-150 words each) add technological texture to existing chapters without structural changes. Editor may incorporate at discretion.

### Chapter 4: Crisis Day
**Location:** Cheney 9/11 section, after "the schedule died"
**Insert:**
> At 9:45 AM, Cheney was in the Presidential Emergency Operations Center beneath the East Wing. The secure phone line to Air Force One—a Raytheon AN/ARC-190 system capable of maintaining encrypted voice through multiple satellite relays—kept cutting out. Not because of equipment failure. Because Air Force One was flying evasive maneuvers, banking hard enough that the fuselage antenna couldn't maintain lock with the satellite. For seventeen minutes, the Vice President couldn't reach the President. The Cold War had ended. We still couldn't keep a phone call connected at 40,000 feet.

### Chapter 6: The Playbook
**Location:** Haldeman section, after "Berlin Wall" discussion
**Insert:**
> The seven-microphone recording system Haldeman ordered installed in February 1971 was supposed to preserve history. Instead, it preserved evidence. The Sony TC-800B recorders ran at 15/16 inches per second—3,700 hours across 950 reels. Every one a potential subpoena. Haldeman had built a system so thorough it couldn't protect even him.

### Chapter 7: The Body's Needs
**Location:** Reagan schedule management section
**Insert:**
> When Reagan's afternoon energy flagged—clockwork, 2:30 PM—Baker had the White House Communications Agency install a dedicated secure phone line in the residence study. Not for crisis calls. For the appearance of presidential activity while Reagan rested. The paperwork showed continuous engagement. The President showed the benefit of REM sleep. Everyone won.

---

## DO NOT CHANGE

- Chapter numbering (Chapters 1-11 remain as numbered)
- Prologue structure
- Epilogue structure
- Existing photography captions
- Table of Contents page numbers (will need recalculation after insertion, but chapter numbers stay same)

---

## PAGE COUNT IMPACT

**Estimated Addition:** 18-22 pages (depending on final layout)
**Current Chapter 8 Length:** [Editor to confirm]
**New Chapter 8 Length:** Current + 18-22 pages

---

## DELIVERABLES ATTACHED

1. **CH-TECHNOLOGY.md** — Full division text, ready for insertion
2. **tech-insertions.md** — Optional short insertions for other chapters
3. **This manifest** — Redline instructions

---

## APPROVAL WORKFLOW

| Step | Action | Owner | Date |
|------|--------|-------|------|
| 1 | Review manifest | Editor | |
| 2 | Confirm insertion location in Chapter 8 | Editor | |
| 3 | Insert division text | Editor/Layout | |
| 4 | Apply optional cross-chapter insertions | Editor | |
| 5 | Recalculate TOC page numbers | Layout | |
| 6 | Author review of integrated text | Omar Salah | |
| 7 | Final approval | Omar Salah | |

---

## NOTES FOR EDITOR

1. **Voice consistency:** The new division maintains Safire voice (65% gravitas, 35% wit) but leans more serious than some earlier chapters per author instruction.

2. **Technical accuracy:** All specifications sourced from multi-model deep research synthesis. Model numbers, weights, and costs are documented in research report (FINAL_RESEARCH_REPORT.md).

3. **CEO/tech appeal:** The division is deliberately written to engage business executives and technology enthusiasts—a secondary audience for the book.

4. **Metropolitan Club scenes:** The opening and closing dining room scenes can be adjusted to match whichever Chiefs are present in surrounding Chapter 8 content. Current draft uses Baker, Cheney, Panetta, Card, Emanuel.

5. **Photography:** If photography is desired for this division, consider:
   - Eisenhower at golf (with car visible)
   - LBJ at desk with phone console
   - Nixon Oval Office (showing sconce microphone locations)
   - Obama with device (campaign era vs. presidency)

---

**End of Manifest**

Prepared by: [Assistant]
For: Omar Salah
Date: January 1, 2026
