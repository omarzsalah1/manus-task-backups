# Enhanced Markdown Editing Guide

## Overview

`MASTER_ENHANCED.md` is a specially formatted version of the book manuscript that makes it easy to:
- **Add pages** to any chapter
- **Rewrite sections** without breaking the build
- **Track changes** automatically
- **Rebuild PDF** with one command

---

## File Structure

### Metadata Header
```markdown
<!--
================================================================================
THE GATEKEEPERS SOCIETY - MASTER MANUSCRIPT (ENHANCED EDITION)
================================================================================

VERSION: V37 Presidential Edition
LAST UPDATED: 2026-01-01
TOTAL PAGES: 521
...
-->
```

### Chapter Markers
```markdown
<!-- ========== START: CHAPTER 1 ========== -->
<!-- METADATA:
     Section: CHAPTER 1
     Start Line: 386
     Last Edited: 2026-01-01
     Status: Production Ready
-->

# CHAPTER 1

## The Sacred Hour

[Your content here...]

<!-- ========== END: CHAPTER 1 ========== -->
```

---

## How to Edit

### 1. **Adding Content to a Chapter**

Find the chapter you want to edit:
```markdown
<!-- ========== START: CHAPTER 3 ========== -->

# CHAPTER 3: BREAKING POINT

## The Breaking Point

[Existing content...]

## NEW SECTION: Your New Content Here  <!-- [EDITED: 2026-01-02] -->

This is the new content I'm adding to Chapter 3.
It will be automatically included in the next build.

[More existing content...]

<!-- ========== END: CHAPTER 3 ========== -->
```

**Key Points**:
- Add content **between** the START/END markers
- Add `[EDITED: YYYY-MM-DD]` tag after sections you modify
- Maintain heading hierarchy (## for sections, ### for subsections)

---

### 2. **Rewriting Existing Content**

Simply edit the text between markers:
```markdown
<!-- ========== START: PROLOGUE ========== -->

# PROLOGUE

## The Papers in the Study  <!-- [EDITED: 2026-01-02] -->

[Your rewritten content here - completely replace the old text]

<!-- ========== END: PROLOGUE ========== -->
```

---

### 3. **Adding a New Chapter**

```markdown
<!-- ========== START: CHAPTER 12 ========== -->
<!-- METADATA:
     Section: CHAPTER 12
     Start Line: NEW
     Last Edited: 2026-01-02
     Status: Draft
-->

# CHAPTER 12: YOUR NEW CHAPTER TITLE

## Section One

Your content here...

## Section Two

More content...

<!-- ========== END: CHAPTER 12 ========== -->
```

---

## Special Elements

### Portraits
```markdown
![Sherman Adams](../design_assets/portraits/01_sherman_adams_eisenhower_CORRECT.png)

*Sherman Adams, Eisenhower's Chief of Staff (1953-1958). The first modern gatekeeper.*
```

### Section Breaks (Dividers)
```markdown
---

[The divider will be automatically converted to a golden ornamental break]
```

### Clock-Stars
Clock-stars are automatically added to chapter openings. No manual markup needed.

---

## Rebuilding After Edits

### Method 1: Automatic Detection
```bash
cd /home/ubuntu/Gatekeepers_REPO_NEW/build
python3 detect_changes_and_rebuild.py
```

**What it does**:
1. Compares MASTER_ENHANCED.md with MASTER.md
2. Identifies which chapters changed
3. Backs up original MASTER.md
4. Updates MASTER.md with your changes
5. Rebuilds PDF automatically
6. Compresses to 9 MB

### Method 2: Manual Rebuild
```bash
# 1. Copy enhanced to master
cp book_source/MASTER_ENHANCED.md book_source/MASTER.md

# 2. Remove metadata comments (optional, script does this)
# sed -i '/<!--.*-->/d' book_source/MASTER.md

# 3. Rebuild
cd build && python3 build_book.py

# 4. Compress
gs -sDEVICE=pdfwrite -dPDFSETTINGS=/printer -dNOPAUSE -dQUIET -dBATCH \
   -sOutputFile=THE_GATEKEEPERS_SOCIETY_V37_PRESIDENTIAL_COMPRESSED.pdf \
   THE_GATEKEEPERS_SOCIETY_V37_PRESIDENTIAL.pdf
```

---

## Workflow Example

### Scenario: Adding 5 pages to Chapter 4

1. **Open** `MASTER_ENHANCED.md`

2. **Find** Chapter 4:
   ```markdown
   <!-- ========== START: CHAPTER 4 ========== -->
   ```

3. **Add** your new content:
   ```markdown
   ## The New Crisis Protocol  <!-- [EDITED: 2026-01-02] -->
   
   [Your 5 pages of new content here...]
   ```

4. **Save** the file

5. **Send** `MASTER_ENHANCED.md` back to AI

6. **AI will**:
   - Detect changes in Chapter 4
   - Update MASTER.md
   - Rebuild PDF (now 526 pages instead of 521)
   - Compress to ~9 MB
   - Push to GitHub

7. **Done!** New PDF ready with your additions

---

## Change Tracking Tags

Add these tags to help AI understand what changed:

```markdown
<!-- [EDITED: 2026-01-02] -->           # Section was edited
<!-- [ADDED: 2026-01-02] -->            # New section added
<!-- [REWRITTEN: 2026-01-02] -->        # Major rewrite
<!-- [EXPANDED: 2026-01-02, +500 words] -->  # Section expanded
```

---

## Best Practices

### ✅ DO
- Keep START/END markers intact
- Add [EDITED] tags after changes
- Maintain heading hierarchy
- Use proper markdown syntax
- Test build after major changes

### ❌ DON'T
- Remove or modify START/END markers
- Delete metadata blocks
- Mix heading levels (don't jump from # to ###)
- Add HTML directly (use markdown)
- Forget to save before sending back

---

## File Locations

| File | Purpose |
|------|---------|
| `MASTER_ENHANCED.md` | **Your editing file** - use this for all edits |
| `MASTER.md` | Production file - auto-updated from enhanced |
| `MASTER_BACKUP.md` | Automatic backup before changes applied |

---

## Troubleshooting

### Build Fails After Edit
1. Check for syntax errors (unmatched brackets, broken links)
2. Verify heading hierarchy (# → ## → ###, no skips)
3. Ensure START/END markers are intact
4. Restore from MASTER_BACKUP.md if needed

### Changes Not Detected
1. Verify you edited `MASTER_ENHANCED.md` (not MASTER.md)
2. Ensure changes are between START/END markers
3. Save file before running detection script

### PDF Page Count Wrong
1. Check for extra page breaks (`<div class="page-break"></div>`)
2. Verify images are correct size
3. Rebuild from scratch if needed

---

## Support

If you encounter issues:
1. Check this README first
2. Review `LLM_BUILD_INSTRUCTIONS.md` in repo root
3. Send MASTER_ENHANCED.md to AI with error description
4. AI will diagnose and fix automatically

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| V37 Enhanced | 2026-01-01 | Initial enhanced markdown with structural markers |

---

**Happy editing!** 🎉
